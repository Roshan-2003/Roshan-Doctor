import React from 'react'
import Navbar from './Componets/Navbar'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Home from './Page/Home'
import About from './Page/About'
import Appoinment from './Page/Appoinment'
import Contact from './Page/Contact'
import Doctor from './Page/Doctor'
import Login from './Page/Login'
import Myappoinment from './Page/Myappoinment'
import Myprofile from './Page/Myprofile'
import Footer from './Componets/Footer'

function App() {
  return (
    <div>
      <BrowserRouter>
<Navbar/>
<Routes>
  <Route path='/' element={<Home/>}/>
  <Route path='/about' element={<About/>}/>
  <Route path='/appoinment/:docId' element={<Appoinment/>}/>
  <Route path='/contact' element={<Contact/>}/> 
  <Route path='/doctor' element={<Doctor/>}/>
  <Route path='/doctor/:speciality' element={<Doctor/>}/>
  <Route path='/login' element={<Login/>}/>
  <Route path='/myappoinmnet' element={<Myappoinment/>}/>
  <Route path='/myprofile' element={<Myprofile/>}/>
</Routes>
<Footer/>
      </BrowserRouter>
    </div>
  )
}

export default App
