import React from 'react'

function Login() {
  return (
    <div>
      Hi Login
    </div>
  )
}

export default Login
