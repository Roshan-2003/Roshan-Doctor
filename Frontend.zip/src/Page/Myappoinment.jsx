import React from 'react'

function Myappoinment() {
  return (
    <div>
      Hii Myappoinment
    </div>
  )
}

export default Myappoinment
