import React, { useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
// import { AppContext } from '../Context/AppContext';
import { assets, doctors } from '../assets/assets_frontend/assets'; // Added doctors import

function Appointment() {
  const { docId } = useParams();
  const [docInfo, setDocInfo] = useState(null);

  const fetchDocInfo = async() => {
    const docInfo = doctors.find(doc => doc._id === docId);
    setDocInfo(docInfo);
    console.log(docInfo);
  };

  useEffect(() => {
    fetchDocInfo();
  }, [docId]);
  

  return docInfo &&(
    <div>
      {/* ****************Doctor Detail**************** */}
      <div className='flex flex-col sm:flax-row gap-4'>
   
            <div>
            <img src={docInfo.image} alt={`${docInfo.name}'s profile`} />
            </div>
            <div>
              {/* ***************Doc Info : name, degree, experience***** */}
              <p>
                {docInfo.name} <img src={assets.verified_icon} alt='Verified icon' />
              </p>
              <div>
                <p>{docInfo.degree} - {docInfo.speciality}</p>
                <button>{docInfo.experience}</button>
              </div>
            </div>
   
   {/* Doctor About*******/}
   <div>
    <p>About <img src={assets.info_icon} alt=''/> </p>
    <p>{docInfo.about}</p>
   </div>
      </div>
    </div>
  );
}

export default Appointment;
