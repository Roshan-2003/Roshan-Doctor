import React from 'react'
import Header from '../Componets/Header'
import Specialist from '../Componets/Specialist'
import TopDoctor from '../Componets/TopDoctor'
import Banner from '../Componets/Banner'

function Home() {
  return (
    <div>
  <Header/>
  <Specialist/>
  <TopDoctor/>
  <Banner/>
    </div>
  )
}

export default Home
