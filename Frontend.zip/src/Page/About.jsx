import React from 'react'

function About() {
  return (
    <div>
     Hii About 
    </div>
  )
}

export default About
