import React from 'react'

function Myprofile() {
  return (
    <div>
      Hiii Myprofile
    </div>
  )
}

export default Myprofile
