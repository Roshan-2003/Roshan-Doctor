import React from 'react'

function Contact() {
  return (
    <div>
      Hii Contact
    </div>
  )
}

export default Contact
