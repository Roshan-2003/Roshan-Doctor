import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import logo from "../assets/assets_frontend/logo.svg"
import profile from "../assets/assets_frontend/profile_pic.png"
import dropdown from "../assets/assets_frontend/dropdown_icon.svg"

const Navbar = () => {
const navigate = useNavigate();
const [showMenu,setShowMenu] = useState(false)
const [token,setToken] = useState(true)

  return (  
 <div className='flex items-center justify-between text-sm py-4 mb-5 border-b border-b-gray-400 ml-10 mr-10'>
  <img onClick={()=>navigate('/')} className='w-44 cursor-pointer' src={logo} alt='Logo'/>
   <ul className='hidden md:flex items-start gap-5 font-small'>
    
     <NavLink to="/" exact activeClassName="active">
     <li className='py-1'>Home</li>
     <hr className='border-none outline-none h-0.5 bg-primary w-3/5 m-auto hidden'/>
      </NavLink>
  
     <NavLink to="/doctor" exact activeClassName="active">
       <li className='py-1'>All Doctors</li>
       <hr className='border-none outline-none h-0.5 bg-primary w-3/5 m-auto hidden'/>
      </NavLink>
  
     <NavLink to="/about" exact activeClassName="active">
      <li className='py-1'> About</li>
      <hr className='border-none outline-none h-0.5 bg-primary w-3/5 m-auto hidden'/>
      </NavLink>
     
     <NavLink to="/contact" exact activeClassName="active">
      <li className='py-1'>Contact</li>
      <hr className='border-none outline-none h-0.5 bg-primary w-3/5 m-auto hidden'/>
      </NavLink>
    
   </ul>
  <div className='flex  item-center gap-4'>
  {
    token ?
    <div className='flex items-center gap-2 cursor-pointer group relative'> 
    <img className='w-8 rounded-full' src={profile} alt=''/>
    <img className='w-2.5' src={dropdown}/>
<div className='absolute top-0 right-0 pt-14 text-base font-medium text-gray-600 z-20 hidden group-hover:block'> 
  <div className='min-w-48 bg-stone-100 rounded flex flex-col gap-4 p-4'> 
  <p onClick={()=>navigate('my-profile')} className='hover:text-black cursor-pointer'>My profile</p>
  <p onClick={()=>navigate('my-appoinments')} className='hover:text-black cursor-pointer'> My Appoinment</p>
  <p onClick={()=>setToken(false)} className='hover:text-black cursor-pointer'>Logout</p>
  </div>
</div>
    </div>
    :
    <button onClick={()=>navigate('/login')} className='bg-primary text-white px-8 py-3 rounded-full font-light hidden md:block'>Create Account</button>
  }
  </div>
</div>
  );
};

export default Navbar;
